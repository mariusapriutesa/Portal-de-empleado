import { NgModule } from '@angular/core';
import { RouterModule, Routes, ExtraOptions } from '@angular/router';

const routes: Routes = [
  {path: 'start' , loadChildren:() => import('./ui/components/start/start.module').then(m => m.StartModule)},

  {path: 'login' , loadChildren:() => import('./ui/components/login/login.module').then(m => m.LoginModule)},
  {path: 'home' , loadChildren:() => import('./ui/components/home/home.module').then(m => m.HomeModule)},
  {path: 'coe' , loadChildren:() => import('./ui/components/coe/coe.module').then(m => m.CoeModule)},
  {path: 'proyectos' , loadChildren:() => import('./ui/components/proyectos/proyectos.module').then(m => m.ProyectosModule)},
  {path: 'programa-mentorias' , loadChildren:() => import('./ui/components/programa-mentorias/programa-mentorias.module').then(m => m.ProgramaMentoriasModule)},
  {path: 'kanban' , loadChildren:() => import('./kanban/kanban.module').then(m => m.KanbanModule)},
  {path: 'recursos-humanos' , loadChildren:() => import('./ui/components/recursos-humanos/recursos-humanos.module').then(m => m.RecursosHumanosModule)},
  {path: 'formacion' , loadChildren:() => import('./ui/components/formacion/formacion.module').then(m => m.FormacionModule)},
  {path: 'informacion-personal' , loadChildren:() => import('./ui/components/informacion-personal/informacion-personal.module').then(m => m.InformacionPersonalModule)},
  {path: 'diagnostico' , loadChildren:() => import('./ui/components/diagnostico/diagnostico.module').then(m => m.DiagnosticoModule)},
  {path: 'desarrollo-personal' , loadChildren:() => import('./ui/components/desarrollo-personal/desarrollo-personal.module').then(m => m.DesarrolloPersonalModule)},
  {path: 'cursos' , loadChildren:() => import('./ui/components/cursos/cursos.module').then(m => m.CursosModule)},
  




  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {anchorScrolling: 'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
