import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//Modulos para inicio de sesion
import { SocialAuthServiceConfig } from 'angularx-social-login';
import { GoogleLoginProvider, FacebookLoginProvider } from 'angularx-social-login';
import { LoginModule } from './ui/components/login/login.module';
import { HttpClientModule } from '@angular/common/http';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HomeModule } from './ui/components/home/home.module';
import { RecursosHumanosDetailComponent } from './ui/components/recursos-humanos/recursos-humanos-detail/recursos-humanos-detail.component';
import { ButtonModule } from 'primeng/button';
import { FormsModule } from '@angular/forms';
import { DataViewModule } from 'primeng/dataview';
import { FooterComponent } from './ui/components/footer/footer.component';
import { BackgComponent } from './ui/components/backg/backg.component';






@NgModule({
  declarations: [
    AppComponent,
    RecursosHumanosDetailComponent,
    FooterComponent,
    BackgComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LoginModule,
    HomeModule,
    ButtonModule,
    FormsModule,
    DataViewModule,
  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '673165623611-al6qlqrtj6oekcpaichacon55lvp86iv.apps.googleusercontent.com'
            )
          }
        ],
        onError: (err) => {
          console.error(err);
        }
      } as SocialAuthServiceConfig,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
