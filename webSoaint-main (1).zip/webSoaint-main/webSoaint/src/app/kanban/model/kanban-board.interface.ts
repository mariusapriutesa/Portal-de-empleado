import { KanbanList } from './kanban-list.interface';

export interface KanbanBoard {
  lists: KanbanList[];
}
