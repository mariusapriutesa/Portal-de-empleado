export interface KanbanTask {
  id: number;
  description: string;
}
