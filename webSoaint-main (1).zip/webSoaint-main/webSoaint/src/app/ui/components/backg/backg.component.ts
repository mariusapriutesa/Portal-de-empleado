import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GoogleApiService } from 'src/app/core/services/google-api.service';

@Component({
  selector: 'app-backg',
  templateUrl: './backg.component.html',
  styleUrls: ['./backg.component.scss']
})
export class BackgComponent implements OnInit {

  constructor(private router: Router, private googleS: GoogleApiService) { }

  ngOnInit(): void {
  }

  volver():void {
    window.history.back();
  }

  salir(): void {
    this.googleS.signOut();
    
  }

  atras(): void {
   this.router.navigateByUrl("/home")
  }
  
}
