import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InformacionPersonalComponent } from './informacion-personal/informacion-personal.component';
import { RouterModule, Routes} from '@angular/router';


const routes: Routes=[
  { path: '', component: InformacionPersonalComponent }
];


@NgModule({
  declarations: [
    InformacionPersonalComponent,

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class InformacionPersonalModule { }
