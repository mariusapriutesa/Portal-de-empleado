import { Component, OnInit } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { Title } from '@angular/platform-browser';

@Component({
	selector: 'app-informacion-personal',
	templateUrl: './informacion-personal.component.html',
	styleUrls: ['./informacion-personal.component.scss']
})
export class InformacionPersonalComponent implements OnInit {


  constructor(private viewportScroller: ViewportScroller,private title: Title) { }


	ngOnInit(): void {

		this.title.setTitle('Información personal');

		/*
		TODO
	
		* CSS grid layout
		* Portfolio links alt attributes
		* Linkedin social link + icon
		* A4 format ratio: √2
		* Vanilla JS
	*/

		$(document).ready(
			function () {
				// Ugly speed-coded nav
				const
					$pages = $('.page'),
					$pageCV = $('.page--cv'),
					$pagePortfolio = $('.page--portfolio'),
					$pageProjects = $('.page--projects'),

					$btns = $('.navbar button'),
					$btnCV = $('.btn--cv'),
					$btnPortfolio = $('.btn--portfolio'),
					$btnProjects = $('.btn--projects')

				const disableAllNavbarItems = () => {
					$btns.parent().removeClass('active')
					$pages.removeClass('active')
				}
				const enableNavbarItem = ($item: JQuery<HTMLElement>, $page: JQuery<HTMLElement>) => {
					$item.parent().addClass('active')
					$page.addClass('active')
				}

				$btnCV.on('click', function () {
					disableAllNavbarItems()
					enableNavbarItem($btnCV, $pageCV)
				})

				$btnPortfolio.on('click', function () {
					disableAllNavbarItems()
					enableNavbarItem($btnPortfolio, $pagePortfolio)
				})

				$btnProjects.on('click', function () {
					disableAllNavbarItems()
					enableNavbarItem($btnProjects, $pageProjects)
				})

			}
		)
	}

  public onClick(elementId: string):void{
    this.viewportScroller.scrollToAnchor(elementId);
  }

}
