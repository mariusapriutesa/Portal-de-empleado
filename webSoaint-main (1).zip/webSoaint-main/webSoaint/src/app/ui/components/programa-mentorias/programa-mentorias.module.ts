import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgramaMentoriasComponent } from './programa-mentorias/programa-mentorias.component';
import { RouterModule, Routes } from '@angular/router';

import {DataViewModule} from 'primeng/dataview';
import { TableModule } from 'primeng/table';
import { FormsModule } from '@angular/forms';
import { FooterComponent } from '../footer/footer.component';

const routes: Routes=[
  { path: '', component: ProgramaMentoriasComponent }
];

@NgModule({
  declarations: [
    ProgramaMentoriasComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    DataViewModule,
    TableModule,
    FormsModule,
  ]
})
export class ProgramaMentoriasModule { }
