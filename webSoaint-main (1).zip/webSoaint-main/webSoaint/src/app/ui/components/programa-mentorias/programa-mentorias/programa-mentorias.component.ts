import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-programa-mentorias',
  templateUrl: './programa-mentorias.component.html',
  styleUrls: ['./programa-mentorias.component.scss']
})
export class ProgramaMentoriasComponent implements OnInit {

  mentorias: any[] = [];
  mentores: any[] = [];
  mentoresTodos: any[] = [];

  cols: any[] = [];
  colsMentores: any[] = [];

  mentorBuscar = "";

  constructor(private title: Title) { }

  ngOnInit(): void {

    this.title.setTitle('Programa mentorías');

    this.cols = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' }
    ];

    this.colsMentores = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' },
      { field: 'surname', header: 'Surname' },
      { field: 'age', header: 'Age' },
      { field: 'email', header: 'Email' },
      { field: 'role', header: 'Role' }
    ];

    this.mentorias = [
      { "code": 1, "name": "Mentoria1" },
      { "code": 2, "name": "Mentoria2" }
    ];

    this.mentores = [
      {
        "code": 1, "name": "José", "surname": "Martinez", "age": 32, "email": "fnyjjh@soaint.com",
        "role": "ROLE_ADMIN", "image": "../../../../../assets/ImagenesRRHHComponent/Persona2.png"
      },
      {
        "code": 2, "name": "Pepe", "surname": "Moreno", "age": 47, "email": "fhfghh@soaint.com",
        "role": "ROLE_ADMIN", "image": "../../../../../assets/ImagenesRRHHComponent/Persona2.png"
      }
    ];

    this.mentoresTodos = this.mentores;

  }

  removeAccents = (str: string) => { //metodo para quitar acentos de un string
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  comprbarAcentos(cadena: string): string {
    var buscar = cadena.toLocaleLowerCase();
    var acentos = ['á', 'é', 'í', 'ó', 'u'];
    for (let i = 0; i < buscar.length; i++) {
      if (acentos.includes(buscar[i])) {
        return cadena;
      }
    }
    return "";
  }

  buscarMentor(): void {
    var mentoresSearch: any[] = [];
    var buscar = this.mentorBuscar.toLowerCase();
    console.log("d"+this.comprbarAcentos(buscar))
    for (let i of this.mentores) {
      var nombre = "";
      var apellidos = "";
      if(this.comprbarAcentos(buscar).length>0) {
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (nombre.includes(buscar) || apellidos.includes(buscar)) {
        mentoresSearch.push(i);
      }
    }
    this.mentores = [...mentoresSearch]
    if (buscar.length == 0) {
      this.mentores = this.mentoresTodos;
    }

  }

}
