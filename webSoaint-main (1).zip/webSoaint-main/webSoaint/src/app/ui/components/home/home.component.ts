import { Component, OnInit } from '@angular/core';
import { DataSet } from 'vis-data';
import { Network } from 'vis-network/standalone';
import { Router } from '@angular/router';
import { GoogleApiService } from 'src/app/core/services/google-api.service';

import { Title } from '@angular/platform-browser';

import { Options } from 'vis';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  cardTitle = '';
  cardText = '';
  cardImage = '';
  constructor(private router: Router, 
                private googleS: GoogleApiService,
                private title: Title) {}
  ngOnInit(): void {

    var imgUrl: String = "../../../../../assets/Cards/";

    this.title.setTitle('Home - SOAINT');

    var rutaImgHexagonos: string = '../../../../assets/Hexagonos/';
    // create an array with nodes

    var rawNodes = [
      
      {
        
        id: 0,
        shape:'image',
        image: rutaImgHexagonos + 'HexaSoaint.png',
        size : 140,
      },
      {
        id: 1,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoCOE.png',
      },
      {
        id: 2,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoRRHH.png',
      },
      {
        id: 3,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoProyectos.png',

      },
      {
        id: 4,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoInforPers.png',
        size: 120
      },
      {
        id: 5,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoMentorias.png',
      },
      {
        id: 6,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoFormacion.png',
      },
      {
        id: 7,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoDiagnostico.png',
      },
      {
        id: 8,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoCursos.png',
      },
      {
        id: 9,
        shape:'image',
        image: rutaImgHexagonos + 'hexagonoDesarrollo.png',
      },
      
    ];
    var nodes = new DataSet(rawNodes);
    // create an array with edges
    var edges = new DataSet([

      {id:0, from: 0, to: 6 },
      { from: 0, to: 2 },
      { from: 0, to: 3 },
      { from: 1, to: 7 },
      { from: 6, to: 5 },
      { from: 6, to: 1 },
      { from: 7, to: 8 },
      { from: 7, to: 9 },
      
    ]);
    // create a network
    var container = document.getElementById('mynetwork');
    // provide the data in the vis format
    var data = {
      nodes: nodes,
      edges: edges,
    };
    var options: Options = {
      
      
      nodes: {

        size: 80,
        shape: "image",

        font: {
          color: '#fff',
          
        
          vadjust: -120
        },
        
        
        
        color:{
          border:"black",
          background:"#597dba",
          hover:"#a6d5f7"

        },

        

      },
      physics: {
        enabled: true,
      },
      edges: {
        color: '#fff',
        labelHighlightBold: false,
        
        width: 7,
        
        physics: false,
        smooth: false,
      },
      layout: {
        
      },
      interaction: {
        dragNodes: false,
        zoomView: false, // do not allow zooming
        dragView: false, // do not allow dragging
        hover: true,
        tooltipDelay: 250,
      },
      
    };
    // initialize your network!
    var network = new Network(container!, data, options);
    // Store Color Variables

    network.moveNode(0, 0, 0); //SOAINT
    network.moveNode(1, -500, -150); //COE
    network.moveNode(2, 0, -275); //Recursos Humanos
    network.moveNode(3, 225, -150); //Proyectos
    network.moveNode(4, -650, -325); //Informacion Personal
    network.moveNode(5, -225, -375); //Mentorias
    network.moveNode(6, -225, -150); //Formacion
    network.moveNode(7, -725, -25); //Diagnostico
    network.moveNode(8, -900, 75); //Cusrsos
    network.moveNode(9, -550, 75); //Desarrollo Personal
    // network.setSize("1200", "800")
    // network.redraw()
    // Run hexagon() to show each point

    
    
    network.on("hoverNode", (a) =>{
      
      var id = a.node
      
      switch(id){
        case 1:
         nodes.update({
           id :id,
           size:120
         })

        break;
        case 2:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 3:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 4:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 5:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 6:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 7:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 8:
          nodes.update({
            id :id,
            size:120
          })
          
          break;
        case 9:
          nodes.update({
            id :id,
            size:120
          })
           break;
      }
      console.log(id)
      
     
  

    

      // ctx.scale(2,2)
      // ctx.fill()
    })

    network.on("blurNode", (a) =>{
      var id = a.node
      
      switch(id){
        case 1:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 2:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 3:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 4:
          nodes.update({
            id :id,
            size:80
          })

          break;
        case 5:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 6:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 7:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 8:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 9:
          nodes.update({
            id :id,
            size:80
          })
           break;
      }

      network.setOptions(options)
  
    })
     
    
    network.on("showPopup", function(s){
      
    })
   

    
    

    const contenidoCard = (id: number): void => {
      switch (id) {
        case 0: {
          this.cardTitle = 'SOAINT';
          this.cardText = 'En SOAINT tenemos un objetivo claro, convertirnos en el partner tecnológico de tu empresa y transformar juntos el futuro.';
          this.cardImage = '../../../../../assets/logo-soaint-cuadrado.png';
          break;
        }
        case 1: {
          this.cardTitle = 'Centro de excelencia';
          this.cardText = 'Es el lugar donde se formulan las mejores prácticas basándose en conocimientos y en datos de la experiencia de nuestra empresa. Estas prácticas eventualmente residen en nuestra cultura, de modo que SOAINT pueden establecer estándares para la organización e implementarlos de manera consistente en todas las plantas y áreas.';
          this.cardImage = imgUrl + 'coe.jpg';
          break;
        }
        case 2: {
          this.cardTitle = 'People & Culture Analyst';
          this.cardText = 'Seguimiento continuo y preparación de datos e informes relacionados con las personas según sea necesario. Procese nuevas contrataciones, promociones y otros cambios internos en BambooHR y brinde asistencia con la entrada de datos y garantice la precisión y la integridad en todos los sistemas.';
          this.cardImage = imgUrl + 'rrhh.jpg';
          break;
        }
        case 3:{ 
          this.cardTitle = 'Proyectos';
          this.cardText = 'Para SOAINT un proyecto es un conjunto ordenado de actividades con el fin de satisfacer ciertas necesidades o resolver problemas específicos. ';
          this.cardImage = imgUrl + 'proyectos.jpg';
          break;
        }

        case 4: {
          this.cardTitle = 'Tus datos Personales';
          this.cardText = 'Contiene detalles sobre ti, basándose en el nombre técnico de tus últimos puestos de trabajo o de tus últimos estudios realizados. Tambien aparece algunos de tus habilidades y conocimientos.  ';
          this.cardImage = imgUrl + 'infoPersonal.jpg';
          break;
        }
        case 5: {
          this.cardTitle = 'Entra en el Programa de Mentoring a tu medida';
          this.cardText = ' Su objetivo es poner en contacto a profesionales dentro de SOAINT con experiencia relevante en alguna área determinada y con la voluntad de compartir información y conocimientos (mentores), con profesionales que puedan beneficiarse de su experiencia, consejo y apoyo para avanzar en sus carreras (mentees). ';
          this.cardImage = imgUrl + 'mentoring.jpg';
          break;
        }
        case 6: {
          this.cardTitle = 'Acerca de tu formación';
          this.cardText = 'La Formación Profesional es el conjunto de acciones que tienen como propósito la formación socio-laboral para y en el trabajo, orientada tanto a la adquisición y mejora de las cualificaciones como a la recualificación de los trabajadores.';
          this.cardImage = imgUrl + 'formacion.jpg';
          break;
        }
        case 7: {
          this.cardTitle = 'Diagnóstico';
          this.cardText = 'Diagnosticar el desarrollo de habilidades, significa que se seleccionen actividades atendiendo al nivel de desarrollo que debería alcanzar, dados los objetivos del nivel y de cada grado y lo que podrá hacer respectivamente.';
          this.cardImage = imgUrl + 'diag.jpg';
          break;
        }
        case 8: {
          this.cardTitle = 'Cursos';
          this.cardText = 'Udemy permite hacer cursos que se ajustan a tu estilo de vida y a tus necesitades.Un curso en Moodle es un área en donde el mentor puede añadir recursos y actividades para que sus estudiantes las completen.';
          this.cardImage = imgUrl + 'cursos.jpg';
          break;
        }
        case 9: {
          this.cardTitle = 'Desarrollo personal';
          this.cardText = 'El desarrollo personal dentro de SOAINT incluye actividades que mejoran la conciencia y la identidad, impulsan el desarrollo de las habilidades personales y de los propios potenciales, contribuyen a construir capital humano y facilitan la empleabilidad, mejoran la calidad de vida, y contribuyen a la realización de sueños y aspiraciones ...';
          this.cardImage = imgUrl + 'desarrollo.jpg';
          break;
        }
      }

    };

    const navegar = (id: number): void => {
      switch (id) {
        case 0: {
          break;
        }
        case 1: {
          this.router.navigate(['/coe']).finally();
          break;
        }
        case 2: {
          this.router.navigate(['/recursos-humanos']).finally();
          break;
        }
        case 3: {
          this.router.navigate(['/proyectos']).finally();
          break;
        }
        case 4: {
          this.router.navigate(['/informacion-personal']).finally();
          break;
        }
        case 5: {
          this.router.navigate(['/programa-mentorias']).finally();
          break;
        }
        case 6: {
          this.router.navigate(['/formacion']).finally();
          break;
        }
        case 7: {
          this.router.navigate(['/diagnostico']).finally();
          break;
        }
        case 8: {
          this.router.navigate(['/cursos']).finally();
          break;
        }
        case 9: {
          this.router.navigate(['/desarrollo-personal']).finally();
          break;
        }
      }
    };

    // Cursor Behavior

    network.on("hoverNode", (a) =>{
      var id = a.node
      switch(id){
        case 1:
         nodes.update({
           id :id,
           size:110
         })
        break;
        case 2:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 3:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 4:
          nodes.update({
            id :id,
            size:140
          })
          break;
        case 5:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 6:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 7:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 8:
          nodes.update({
            id :id,
            size:110
          })
          break;
        case 9:
          nodes.update({
            id :id,
            size:110
          })
           break;
      }
      container!.style.cursor = 'pointer'
      contenidoCard(id)
    })
    network.on("blurNode", (a) =>{
      
      var id = a.node
      switch(id){
        case 1:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 2:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 3:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 4:
          nodes.update({
            id :id,
            size:120
          })
          break;
        case 5:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 6:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 7:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 8:
          nodes.update({
            id :id,
            size:80
          })
          break;
        case 9:
          nodes.update({
            id :id,
            size:80
          })
           break;
      }
      container!.style.cursor = 'default';
      this.cardTitle = '';
      
    })

    network.on('click', (properties) => {
      var id = properties.nodes[0];
      // var clickedNotes = nodes.get(id);
      //console.log("id: " + JSON.stringify(clickedNotes))
      
      // console.log(properties.nodes[0])
      switch(id){
        case 1:
            this.router.navigate(['/coe']).finally();
          break;
        case 2:
            this.router.navigate(['/recursos-humanos']).finally();
          break;
        case 3:
            this.router.navigate(['/proyectos']).finally();
          break;
        case 4:
            this.router.navigate(['/informacion-personal']).finally();
          break;
        case 5:
            this.router.navigate(['/programa-mentorias']).finally();
          break;
        case 6:
            this.router.navigate(['/formacion']).finally();
          break;
        case 7:
            this.router.navigate(['/diagnostico']).finally();
          break;
        case 8:
            this.router.navigate(['/cursos']).finally();
          break;
        case 9:
            this.router.navigate(['/desarrollo-personal']).finally();
          break;
      }

    });

    // this.googleS.userProfileSubject.subscribe( info => {
    //   console.log("Email: "+info.info.email)
    // })
  }

  salir(): void {
    this.googleS.signOut();
  }
}
