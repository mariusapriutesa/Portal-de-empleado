import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesarrolloPersonalComponent } from './desarrollo-personal/desarrollo-personal.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes=[
  { path: '', component: DesarrolloPersonalComponent }
];

@NgModule({
  declarations: [
    DesarrolloPersonalComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
  ]
})
export class DesarrolloPersonalModule { }
