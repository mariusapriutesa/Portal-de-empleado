import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-desarrollo-personal',
  templateUrl: './desarrollo-personal.component.html',
  styleUrls: ['./desarrollo-personal.component.scss']
})
export class DesarrolloPersonalComponent implements OnInit {

  constructor(private title: Title) { }

  ngOnInit(): void {
    this.title.setTitle('Desarrollo personal');
    
    
  }

}
