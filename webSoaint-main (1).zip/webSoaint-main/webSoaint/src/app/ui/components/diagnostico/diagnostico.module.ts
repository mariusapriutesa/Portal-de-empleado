import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiagnosticoComponent } from './diagnostico/diagnostico.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes=[
  { path: '', component: DiagnosticoComponent }
];

@NgModule({
  declarations: [
    DiagnosticoComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule
  ]
})
export class DiagnosticoModule { }
