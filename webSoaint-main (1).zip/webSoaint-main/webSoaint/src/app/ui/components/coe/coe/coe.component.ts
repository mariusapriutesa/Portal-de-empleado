import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-coe',
  templateUrl: './coe.component.html',
  styleUrls: ['./coe.component.scss']
})
export class CoeComponent implements OnInit {

 

  constructor(private title: Title) { }

  ngOnInit(): void {

    this.title.setTitle('COE');
    
  }

}
