import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { RecursosHumanosComponent } from '../recursos-humanos/recursos-humanos.component';

@Component({
  selector: 'app-recursos-humanos-form',
  templateUrl: './recursos-humanos-form.component.html',
  styleUrls: ['./recursos-humanos-form.component.scss']
})
export class RecursosHumanosFormComponent implements OnInit {
  userId!: number;
  formRegistro!: FormGroup;
  titulo = "";
  tituloForm = "";
  accion = "";
  imagen = "";
  imagenInicial = "../../../../../assets/ImagenInicial.png";

  constructor(private title: Title,
    private route: ActivatedRoute,
    private rh: RecursosHumanosComponent,
    private router: Router) {
  }

  ngOnInit(): void {
    this.cargarForm();
  }

  cargarForm(): void {
    var nombre: String | null;
    var apellidos: String | null;
    var email: String | null;
    var age: String | null;
    var image: String | null;
    var role = "";
    var perfil = "";

    this.userId = this.route.snapshot.params['id'];
    if (this.userId) {
      var user = {
        id: 0,
        name: "",
        surname: "",
        email: "",
        age: "",
        image: "",
        role: "",
        perfil: ""
      };
      if (this.userId <= this.rh.integrantesProyecto.length)
        user = this.rh.integrantesProyecto[this.userId - 1];
      else {
        for (var i = 0; i < localStorage.length; i++) {
          var clave = localStorage.key(i);
          var valor = "";
          if (clave) {
            valor = localStorage.getItem(clave) + "";
          }
          if (i + 1 == this.userId - this.rh.integrantesProyecto.length) {
            user = JSON.parse(valor);
          }

        }
      }
      nombre = user.name;
      apellidos = user.surname;
      email = user.email;
      age = user.age;
      image = user.image;
      role = user.role;
      perfil = user.perfil;
      console.log(role + " " + perfil)
      this.accion = "ACTUALIZAR";
      this.titulo = "ACTUALIZAR PERFIL SOAINT";
      this.tituloForm = "ACTUALIZAR AQUÍ";
      this.imagen = user.image;

      this.title.setTitle('Recursos humanos - Actualizar - '+nombre+' '+apellidos);
    } else {
      nombre = null;
      apellidos = null;
      email = null;
      age = null;
      image = null;
      role = "ROLE_USER";
      perfil = "Técnico";
      this.accion = "REGISTRARSE";
      this.titulo = "REGISTRARSE EN SOAINT";
      this.tituloForm = "REGISTRARSE AQUÍ";
      this.imagen = this.imagenInicial;
      this.title.setTitle('Recursos humanos - Registrar');
    }
    this.formRegistro = new FormGroup({
      name: new FormControl(nombre, [Validators.required]),
      surname: new FormControl(apellidos, [Validators.required]),
      email: new FormControl(email, [Validators.required, Validators.email]),
      age: new FormControl(age, [Validators.required]),
      image: new FormControl(image, [Validators.required]),
      role: new FormControl(role, [Validators.required]),
      perfil: new FormControl(perfil, [Validators.required])
    });
  }

  onFormSubmit(): void {
    if (this.userId) {
      this.actualizar();
    } else {
      this.registrar();
    }
    this.router.navigate(['/recursos-humanos']).finally();
  }

  actualizar(): void {
    const data = this.formRegistro.value;
    alert(data.name + " " + data.surname + " ha sido actualizado.");
  }

  registrar(): void {
    const data = this.formRegistro.value;
    const addData = {
      id: this.rh.integrantesProyecto.length + localStorage.length + 1
    }
    const finalResult = Object.assign(data, addData);
    localStorage.setItem(data.email, JSON.stringify(finalResult));
    this.router.navigate(['/recursos-humanos']).finally();
    //alert(data.name + " " + data.surname + " ha sido registrado.");
  }

  cambiarFoto = (url: string) => {
    if (url.length == 0) {
      this.imagen = this.imagenInicial;
    } else {
      this.imagen = url;
      const imgs = Array.from(document.querySelectorAll('img'));
      imgs.forEach(i => i.addEventListener('error', event => {
        console.log('Falló la carga');
        this.imagen = this.imagenInicial;
      })
      );
    }
  }

}
