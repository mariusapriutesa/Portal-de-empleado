import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { RecursosHumanosComponent } from './recursos-humanos/recursos-humanos.component';
import { DataViewModule } from 'primeng/dataview';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RecursosHumanosFormComponent } from './recursos-humanos-form/recursos-humanos-form.component';
import { ButtonModule } from 'primeng/button';
import { RecursosHumanosDetailComponent } from './recursos-humanos-detail/recursos-humanos-detail.component';
import { TooltipModule } from 'primeng/tooltip';

const routes: Routes = [
  { path: '', component: RecursosHumanosComponent },
  { path: 'form', component: RecursosHumanosFormComponent },
  { path: 'form/update/:id', component: RecursosHumanosFormComponent },
  { path: ':id', component: RecursosHumanosDetailComponent }
];

@NgModule({
  declarations: [
    RecursosHumanosComponent,
    RecursosHumanosFormComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    DataViewModule,
    ButtonModule,
    FormsModule,
    ReactiveFormsModule,
    TooltipModule

  ],
  providers: [RecursosHumanosComponent]
})
export class RecursosHumanosModule { }
