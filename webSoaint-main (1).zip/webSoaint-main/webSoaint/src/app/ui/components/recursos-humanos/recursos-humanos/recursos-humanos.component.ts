import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-recursos-humanos',
  templateUrl: './recursos-humanos.component.html',
  styleUrls: ['./recursos-humanos.component.scss']
})
export class RecursosHumanosComponent implements OnInit {

  imgUrl: String = "../../../../assets/ImagenesRRHHComponent/"


  integrantesProyecto: any[] = [
    {
      "id": 1, "name": "Pedro", "surname": "García", "age": 29, "email": "fnyjjh@soaint.com",
      "role": "ROLE_ADMIN", "image": this.imgUrl + 'Persona1.png',
      "proyectos": ['Proyecto1', 'Proyecto3'], "perfil": "Técnico"
    },
    {
      "id": 2, "name": "Luis", "surname": "López", "age": 41, "email": "fhfghh@soaint.com",
      "role": "ROLE_ADMIN", "image": this.imgUrl + 'Persona2.png',
      "proyectos": ['Proyecto2'], "perfil": "Técnico"
    },
    {
      "id": 3, "name": "Carlos", "surname": "Pérez", "age": 36, "email": "rthyh@soaint.com",
      "role": "ROLE_ADMIN", "image": this.imgUrl + 'Persona3.png',
      "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
    },
    {
      "id": 4, "name": "David", "surname": "fbdfb", "age": 36, "email": "rthyh@soaint.com",
      "role": "ROLE_ADMIN", "image": this.imgUrl + 'Persona4.png',
      "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
    },
    {
      "id": 5, "name": "Mario", "surname": "yjtyj", "age": 27, "email": "yjtyj@soaint.com",
      "role": "ROLE_ADMIN", "image": this.imgUrl + 'Persona5.png',
      "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
    }
  ];
  integrantesProyectoTodos: any[] = []; //para poder hacer búsquedas

  cols: any[] = [];

  usuarioBuscar = "";
  constructor(private title: Title) { }

  ngOnInit(): void {

    var imgUrl: String = "../../../../assets/ImagenesRRHHComponent/"

    this.title.setTitle('Recursos humanos');

    this.cols = [
      { field: 'id', header: 'Id' },
      { field: 'name', header: 'Name' },
      { field: 'surname', header: 'Surname' },
      { field: 'age', header: 'Age' },
      { field: 'email', header: 'Email' },
      { field: 'role', header: 'Role' },
      { field: 'perfil', header: 'Perfil' },
    ];
    this.cargarIntegrantes();
    this.integrantesProyectoTodos = this.integrantesProyecto;
  }

  removeAccents = (str: string) => { //metodo para quitar acentos de un string
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  comprbarAcentos(cadena: string): string {
    var buscar = cadena.toLocaleLowerCase();
    var acentos = ['á', 'é', 'í', 'ó', 'u'];
    for (let i = 0; i < buscar.length; i++) {
      if (acentos.includes(buscar[i])) {
        return cadena;
      }
    }
    return "";
  }

  buscarIntegrante(): void {
    //console.log(this.usuarioBuscar)
    var integrantesProyectoSearch: any[] = [];
    var buscar = this.usuarioBuscar.toLowerCase();
    for (let i of this.integrantesProyecto) {
      var nombre = "";
      var apellidos = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (nombre.includes(buscar) || apellidos.includes(buscar)) {
        integrantesProyectoSearch.push(i);
      }
    }
    this.integrantesProyectoTodos = [...integrantesProyectoSearch]
    console.log(this.integrantesProyectoTodos)
  }

  cargarIntegrantes(): void {
    for (var i = 0; i < localStorage.length; i++) {
      var clave = localStorage.key(i);
      var valor = "";
      if (clave) {
        valor = localStorage.getItem(clave) + "";
      }
      this.integrantesProyecto.push(JSON.parse(valor));
    }
  }

}
