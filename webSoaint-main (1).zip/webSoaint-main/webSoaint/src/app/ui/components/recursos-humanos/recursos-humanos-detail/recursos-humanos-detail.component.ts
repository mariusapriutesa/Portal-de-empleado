import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router, RoutesRecognized } from '@angular/router';
import { filter, pairwise } from 'rxjs';
import { RecursosHumanosComponent } from '../recursos-humanos/recursos-humanos.component';

@Component({
  selector: 'app-recursos-humanos-detail',
  templateUrl: './recursos-humanos-detail.component.html',
  styleUrls: ['./recursos-humanos-detail.component.scss']
})
export class RecursosHumanosDetailComponent implements OnInit {

  userId!: number;
  nombre = "";
  apellidos = "";
  email = "";
  edad = "";
  role = "";
  imagen = "";

  cursosMatriculado: any[] = [];
  cursosMatriculadoTodos: any[] = [];
  cursosMatriculadosBuscar = "";

  previousUrl: string = "";
  constructor(private title: Title,
    private route: ActivatedRoute,
    private rh: RecursosHumanosComponent,
    private router: Router) {


  }

  ngOnInit(): void {
    
    this.cargarUsuario();

    this.title.setTitle('Recursos humanos - Detalles - ' + this.nombre + ' ' + this.apellidos);

    var imgUrl: String = "../../../../../assets/";

    this.cursosMatriculado = [
      { "code": 1, "name": "JS", "image": imgUrl + "ImagenesCursosComponent/JavaScript.png" },
      { "code": 2, "name": "Java", "image": imgUrl + "ImagenesCursosComponent/Java.png" },
      { "code": 3, "name": "Angular", "image": imgUrl + "ImagenesCursosComponent/Angular.png" }
    ];

    this.cursosMatriculadoTodos = this.cursosMatriculado;
  }

  cargarUsuario(): void {
    this.userId = this.route.snapshot.params['id'];
    var user = {
      id: 0,
      name: "",
      surname: "",
      email: "",
      age: "",
      image: "",
      role: "",
      perfil: ""
    };
    if (this.userId <= this.rh.integrantesProyecto.length)
      user = this.rh.integrantesProyecto[this.userId - 1];
    else {
      for (var i = 0; i < localStorage.length; i++) {
        var clave = localStorage.key(i);
        var valor = "";
        if (clave) {
          valor = localStorage.getItem(clave) + "";
        }
        if (i + 1 == this.userId - this.rh.integrantesProyecto.length) {
          user = JSON.parse(valor);
        }

      }
    };

    this.nombre = user.name;
    this.apellidos = user.surname;
    this.email = user.email;
    this.edad = user.age;
    this.role = user.role;
    this.imagen = user.image;
  }

  buscarCursosMatriculados(): void {
    var cursosMatriculadosSearch: any[] = [];
    for (let c of this.cursosMatriculado) {
      if (c.name.toLowerCase().includes(this.cursosMatriculadosBuscar.toLowerCase())) {
        cursosMatriculadosSearch.push(c);
      }
    }
    this.cursosMatriculadoTodos = [...cursosMatriculadosSearch]
  }

}
