import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormacionComponent } from './formacion/formacion.component';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from '../footer/footer.component';


const routes: Routes=[
  { path: '', component: FormacionComponent }
];

@NgModule({
  declarations: [
    FormacionComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
   //FooterComponent
    
  ]
})
export class FormacionModule { }
