import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-proyectos',
  templateUrl: './proyectos.component.html',
  styleUrls: ['./proyectos.component.scss']
})

export class ProyectosComponent implements OnInit {
  integrantesProyecto: any[] = [];
  integrantesProyectoTodos: any[] = []; //para poder hacer búsquedas
  misProyectos: any[] = [];
  misProyectosTodos: any[] = [];
  cols: any[] = [];
  colsProyectos: any[] = [];
  usuarioBuscar = "";
  proyectoBuscar = "";
  selectedProject = "todosProyectos";//value del option por defecto
  selectedRole = "todosRoles";
  botonDesactivado = true;
  infoBuscarIntegrantes = "";
  page!: number;


  constructor(private title: Title) { }

  ngOnInit(): void {
    var rutaImg: string = '../../../../assets/ImagenesProyectosComponent/';
    this.title.setTitle('Proyectos');
    this.cols = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' },
      { field: 'surname', header: 'Surname' },
      { field: 'age', header: 'Age' },
      { field: 'email', header: 'Email' },
      { field: 'role', header: 'Role' }
    ];
    this.integrantesProyecto = [
      {
        "code": 1, "name": "Pedro", "surname": "García", "age": 29, "email": "fnyjjh@soaint.com",
        "role": "ROLE_ADMIN", "image": rutaImg + 'User1.png',
        "proyectos": ['Proyecto1', 'Proyecto3'], "perfil": "Técnico"
      },
      {
        "code": 2, "name": "Luis", "surname": "López", "age": 41, "email": "fhfghh@soaint.com",
        "role": "ROLE_USER", "image": rutaImg + 'User2.png',
        "proyectos": ['Proyecto2'], "perfil": "Técnico"
      },
      {
        "code": 3, "name": "Carlos", "surname": "Pérez", "age": 36, "email": "rthyh@soaint.com",
        "role": "ROLE_ADMIN", "image": rutaImg + 'User3.png',
        "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
      },
      {
        "code": 4, "name": "David", "surname": "fbdfb", "age": 36, "email": "rthyh@soaint.com",
        "role": "ROLE_USER", "image": rutaImg + 'User2.png',
        "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
      },
      {
        "code": 5, "name": "Mario", "surname": "yjtyj", "age": 27, "email": "yjtyj@soaint.com",
        "role": "ROLE_ADMIN", "image": rutaImg + 'User1.png',
        "proyectos": ['Proyecto1', 'Proyecto2'], "perfil": "Técnico"
      }
    ];
    this.colsProyectos = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' }
    ];
    this.misProyectos = [
      {
        "code": 1,
        "name": "Proyecto1",
        "image": rutaImg + 'Proyecto1.png'
      },
      {
        "code": 2,
        "name": "Proyecto2",
        "image": rutaImg + 'Proyecto2.png'
      },
      {
        "code": 3,
        "name": "Proyecto3",
        "image": rutaImg + 'Proyecto3.png'
      }
    ];
    this.integrantesProyectoTodos = this.integrantesProyecto;
    this.misProyectosTodos = this.misProyectos;

  }

  removeAccents = (str: string) => { //metodo para quitar acentos de un string
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  comprbarAcentos(cadena: string): string {
    var buscar = cadena.toLocaleLowerCase();
    var acentos = ['á', 'é', 'í', 'ó', 'ú'];
    for (let i = 0; i < buscar.length; i++) {
      if (acentos.includes(buscar[i])) {
        return cadena;
      }
    }
    return "";
  }

  buscarProyecto(): void {
    //buscar en la lista de misProyectos
    var proyectosSearch: any[] = [];
    var buscar = this.proyectoBuscar.toLowerCase();
    for (let p of this.misProyectos) {
      var nombre = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        nombre = p.name.toLowerCase();
      } else {
        nombre = this.removeAccents(p.name.toLowerCase());
      }

      if (nombre.includes(buscar)) {
        proyectosSearch.push(p);
      }
    }
    this.misProyectosTodos = [...proyectosSearch]
  }

  filtroProyecto(lista: any[]): any[] {
    if (this.selectedProject == "todosIntegrantes") {
      //si quitamos la selección dejamos los que coincidan por nombre
      this.integrantesProyectoTodos = this.integrantesProyecto;
    } else { //buscamos que coincidan por proyecto
      for (let i of this.integrantesProyecto) {
        if (i.proyectos.includes(this.selectedProject)) {
          lista.push(i);
        }
      }
    }

    return lista;
  }

  filtroRole(lista: any[]): any[] {
    if (this.selectedRole == "todosRoles") {
      this.integrantesProyectoTodos = this.integrantesProyecto;
    } else {
      for (let i of this.integrantesProyecto) {
        if (i.role == this.selectedRole) {
          lista.push(i);
        }
      }
    }
    return lista;
  }

  filtroNombre(lista: any[]): any[] {
    //si no hay ningún proyecto del select seleccionado buscamos solo por nombre y apellidos
    var buscar = this.usuarioBuscar.toLowerCase();
    for (let i of this.integrantesProyecto) {
      var nombre = "";
      var apellidos = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        // si el integrante buscado tiene acento, no le quitamos las tildes a los 
        // nombres y apellidos con los que se comparen
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        // si no los tiene, quitamos los acentos por si al usuario se le ha olvidado ponerlos
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (this.comprbarAcentos(buscar).length > 0 &&
        (nombre.includes(this.comprbarAcentos(buscar))
          || apellidos.includes(this.comprbarAcentos(buscar)))) {
        lista.push(i);
      } else if (nombre.includes(buscar) || apellidos.includes(buscar)) {
        lista.push(i);
      }
    }
    return lista;
  }

  filtroNombreYProyecto(lista: any[]): any[] {
    //buscamos por nombre y proyecto
    var buscar = this.usuarioBuscar.toLowerCase();
    for (let i of this.integrantesProyecto) {
      var nombre = "";
      var apellidos = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (i.proyectos.includes(this.selectedProject) &&
        this.comprbarAcentos(buscar).length > 0 &&
        (nombre.includes(this.comprbarAcentos(buscar))
          || apellidos.includes(this.comprbarAcentos(buscar)))) {
        lista.push(i);
      } else if (i.proyectos.includes(this.selectedProject) &&
        (nombre.includes(buscar) || apellidos.includes(buscar))) {
        lista.push(i);
      }
    }
    return lista;
  }

  filtroProyectoYRole(lista: any[]): any[] {
    //buscamos por proyecto y role
    for (let i of this.integrantesProyecto) {
      if (i.proyectos.includes(this.selectedProject) &&
        i.role == this.selectedRole) {
        lista.push(i);
      }
    }
    return lista;
  }

  filtroNombreYRole(lista: any[]): any[] {
    //buscamos por nombre y role
    var buscar = this.usuarioBuscar.toLowerCase();
    for (let i of this.integrantesProyecto) {
      var nombre = "";
      var apellidos = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (i.role == this.selectedRole &&
        this.comprbarAcentos(buscar).length > 0 &&
        (nombre.includes(this.comprbarAcentos(buscar))
          || apellidos.includes(this.comprbarAcentos(buscar)))) {
        lista.push(i);
      } else if (i.role == this.selectedRole &&
        (nombre.includes(buscar) || apellidos.includes(buscar))) {
        lista.push(i);
      }
    }
    return lista;
  }

  filtroTodos(lista: any[]): any {
    //buscamos por nombre, role y categoria
    var buscar = this.usuarioBuscar.toLowerCase();
    for (let i of this.integrantesProyecto) {
      var nombre = "";
      var apellidos = "";
      if (this.comprbarAcentos(buscar).length > 0) {
        nombre = i.name.toLowerCase();
        apellidos = i.surname.toLowerCase();
      } else {
        nombre = this.removeAccents(i.name.toLowerCase());
        apellidos = this.removeAccents(i.surname.toLowerCase());
      }

      if (i.proyectos.includes(this.selectedProject) &&
        i.role == this.selectedRole &&
        this.comprbarAcentos(buscar).length > 0 &&
        (nombre.includes(this.comprbarAcentos(buscar))
          || apellidos.includes(this.comprbarAcentos(buscar)))) {
        lista.push(i);
      } else if (i.proyectos.includes(this.selectedProject) &&
        i.role == this.selectedRole &&
        (nombre.includes(buscar) || apellidos.includes(buscar))) {
        lista.push(i);
      }
    }
    return lista;
  }

  asignar(lista: any[]): void {
    this.integrantesProyectoTodos = [...lista];
    if (lista.length == 0) {
      this.infoBuscarIntegrantes = "No existen coincidencias.";
    } else {
      this.infoBuscarIntegrantes = "";
    }

    if (this.selectedProject == "todosProyectos"
      && this.selectedRole == "todosRoles"
      && this.usuarioBuscar.length == 0) {

      this.integrantesProyectoTodos = this.integrantesProyecto;
      this.infoBuscarIntegrantes = "";
      this.botonDesactivado = true;
    } else {
      this.botonDesactivado = false;
    }

    this.page = 0;
  }

  comprobarTodosFiltros(): boolean {
    if (this.selectedProject != "todosProyectos"
      && this.selectedRole != "todosRoles"
      && this.usuarioBuscar.length > 0) {
      return true;
    }
    return false;
  }

  comprobarNombreYProyecto(): boolean {
    if (this.selectedProject != "todosProyectos"
      && this.selectedRole == "todosRoles"
      && this.usuarioBuscar.length > 0) {
      return true;
    }
    return false;
  }

  comprobarNombreYRole(): boolean {
    if (this.selectedProject == "todosProyectos"
      && this.selectedRole != "todosRoles"
      && this.usuarioBuscar.length > 0) {
      return true;
    }
    return false;
  }

  comprobarProyectoYRole(): boolean {
    if (this.selectedProject != "todosProyectos"
      && this.selectedRole != "todosRoles"
      && this.usuarioBuscar.length == 0) {
      return true;
    }
    return false;
  }

  comprobarProyecto(): boolean {
    if (this.selectedProject != "todosProyectos"
      && this.selectedRole == "todosRoles"
      && this.usuarioBuscar.length == 0) {
      return true;
    }
    return false;
  }

  comprobarRole(): boolean {
    if (this.selectedProject == "todosProyectos"
      && this.selectedRole != "todosRoles"
      && this.usuarioBuscar.length == 0) {
      return true;
    }
    return false;
  }

  comprobarNombre(): boolean {
    if (this.selectedProject == "todosProyectos"
      && this.selectedRole == "todosRoles"
      && this.usuarioBuscar.length > 0) {
      return true;
    }
    return false;
  }

  buscarIntegrante(): void {
    var integrantesProyectoSearch: any[] = [];

    if (this.comprobarNombre())
      this.filtroNombre(integrantesProyectoSearch);
    if (this.comprobarRole())
      this.filtroRole(integrantesProyectoSearch);
    if (this.comprobarProyecto())
      this.filtroProyecto(integrantesProyectoSearch);
    if (this.comprobarProyectoYRole())
      this.filtroProyectoYRole(integrantesProyectoSearch);
    if (this.comprobarNombreYRole())
      this.filtroNombreYRole(integrantesProyectoSearch);
    if (this.comprobarNombreYProyecto())
      this.filtroNombreYProyecto(integrantesProyectoSearch);
    if (this.comprobarTodosFiltros())
      this.filtroTodos(integrantesProyectoSearch);

    this.asignar(integrantesProyectoSearch);
  }


  quitarFiltroIntegrantes(): void {
    this.usuarioBuscar = "";
    this.selectedProject = "todosProyectos";
    this.selectedRole = "todosRoles";
    this.infoBuscarIntegrantes = "";
    this.botonDesactivado = true;
    this.integrantesProyectoTodos = this.integrantesProyecto;
    this.page = 0;
  }

}