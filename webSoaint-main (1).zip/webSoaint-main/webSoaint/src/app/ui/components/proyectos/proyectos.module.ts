import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProyectosComponent } from './proyectos/proyectos.component';
import { RouterModule, Routes } from '@angular/router';

import {DataViewModule} from 'primeng/dataview';
import { FormsModule } from '@angular/forms';
// import { FooterComponent } from '../formacion/formacion/footer/footer.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ButtonModule } from 'primeng/button';

const routes: Routes=[
  { path: '', component: ProyectosComponent }
];


@NgModule({
  declarations: [
    ProyectosComponent,
    // FooterComponent,
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    DataViewModule,
    FormsModule,
    NgxPaginationModule,
    ButtonModule,
  ]
})
export class ProyectosModule { }
