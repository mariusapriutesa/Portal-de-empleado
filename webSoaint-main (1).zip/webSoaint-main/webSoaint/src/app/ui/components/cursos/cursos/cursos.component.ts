import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.scss']
})
export class CursosComponent implements OnInit {

  cursosMatriculado: any[] = [];
  cursosTerminados: any[] = [];
  cursosDisponibles: any[] = [];

  //para poder hacer búsquedas
  cursosMatriculadoTodos: any[] = [];
  cursosTerminadosTodos: any[] = [];
  cursosDisponiblesTodos: any[] = [];
  
  cols: any[] = [];
  colsDisponibles: any[] = [];

  cursosMatriculadosBuscar = "";
  cursosTerminadosBuscar = "";
  cursosDisponiblesBuscar = "";

  constructor(private title: Title) { }

  ngOnInit(): void {

    this.title.setTitle('Cursos');

    this.cols = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' }
    ];
    this.colsDisponibles = [
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' },
      { field: 'matricularse', header: 'Matricularse' }
    ];

    var rutaImg: string = '../../../../assets/ImagenesCursosComponent/';


    this.cursosMatriculado = [
      {"code":1, "name":"JavaScript", "image": rutaImg + 'JavaScript.png'},
      {"code":2, "name":"Java", "image": rutaImg + 'Java.png'},
      {"code":3, "name":"Ángular", "image": rutaImg + 'Angular.png'} //de freepng
    ];
    this.cursosTerminados = [
      {"code":1, "name":"PHP", "image": rutaImg + 'PHP.png'}
    ];
    this.cursosDisponibles = [
      {"code":1, "name":"Python", "image": rutaImg + 'Python.png'},
      {"code":2, "name":"JQuery", "image": rutaImg + 'jQuery.png'} //de freepng
    ];

    this.cursosMatriculadoTodos = this.cursosMatriculado;
    this.cursosTerminadosTodos = this.cursosTerminados;
    this.cursosDisponiblesTodos = this.cursosDisponibles;

  }

  matricularse(curso: any) {
    alert("Matriculado en "+curso.name)
    //console.log("Matriculado en "+code.name)
  }

  removeAccents = (str:string) => { //metodo para quitar acentos de un string
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } 

  comprbarAcentos(cadena: string): string {
    var buscar = cadena.toLocaleLowerCase();
    var acentos = ['á', 'é', 'í', 'ó', 'u'];
    for (let i = 0; i < buscar.length; i++) {
      if (acentos.includes(buscar[i])) {
        return cadena;
      }
    }
    return "";
  }

  buscarCursosMatriculados(): void {
    var cursosMatriculadosSearch: any[] = [];
    var buscar = this.cursosMatriculadosBuscar.toLowerCase();
    for(let c of this.cursosMatriculado) {
      var nombre = "";
      if(this.comprbarAcentos(buscar).length>0) {
        nombre = c.name.toLowerCase();
      } else {
        nombre = this.removeAccents(c.name.toLowerCase());
      }

      if(nombre.includes(buscar) ) {
        cursosMatriculadosSearch.push(c);
      }
    }
    this.cursosMatriculadoTodos = [...cursosMatriculadosSearch]
  }

  buscarCursosTerminados(): void {
    var cursosTerminadosSearch: any[] = [];
    var buscar = this.cursosTerminadosBuscar.toLowerCase();
    for(let c of this.cursosTerminados) {
      var nombre = "";
      if(this.comprbarAcentos(buscar).length>0) {
        nombre = c.name.toLowerCase();
      } else {
        nombre = this.removeAccents(c.name.toLowerCase());
      }

      if(nombre.includes(buscar) ) {
        cursosTerminadosSearch.push(c);
      }
    }
    this.cursosTerminadosTodos = [...cursosTerminadosSearch]
  }

  buscarCursosDisponibles(): void {
    var cursosDisponiblesSearch: any[] = [];
    var buscar = this.cursosDisponiblesBuscar.toLowerCase();
    for(let c of this.cursosDisponibles) {
      var nombre = "";
      if(this.comprbarAcentos(buscar).length>0) {
        nombre = c.name.toLowerCase();
      } else {
        nombre = this.removeAccents(c.name.toLowerCase());
      }
      
      if(nombre.includes(buscar) ) {
        cursosDisponiblesSearch.push(c);
      }
    }
    this.cursosDisponiblesTodos = [...cursosDisponiblesSearch]
  }

}
